package com.example.loginbooka;

public class Server {
//    public static final String URL = "http://192.168.4.3:8000";
    public static final String URL = "http://192.168.4.2:8000";
//    public static final String URL = "http://192.168.100.2:8000";

}
