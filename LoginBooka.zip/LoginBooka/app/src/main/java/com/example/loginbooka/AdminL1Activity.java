package com.example.loginbooka;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONObject;

import java.util.List;

public class AdminL1Activity extends ListActivity implements FetchDataListener{
    private ProgressDialog dialog;
    Button closed,opened;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_l1);
        initView();

        opened = findViewById(R.id.admin_open);
        closed = findViewById(R.id.admin_close);

        closed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dataClose();
            }
        });
        opened.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dataOpen();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent setIntent = new Intent(AdminL1Activity.this, AdminRentLockerActivity.class);
        finish();
        startActivity(setIntent);
    }

    private void initView() {
        // show progress dialog
//        dialog = ProgressDialog.show(this, "", "Loading...");

        String url = "http://192.168.4.2:8000/APIHistoryl1?loker=l1pnj";
//        String url = "http://192.168.100.2:8000/APIHistoryl1?loker=l1pnj";
        FetchDataTask task = new FetchDataTask(this);
        task.execute(url);
    }

    @Override
    public void onFetchComplete(List<Application> data) {
        // dismiss the progress dialog
        if(dialog != null)  dialog.dismiss();
        // create new adapter
        ApplicationAdapter adapter = new ApplicationAdapter(this, data);
        // set the adapter to list
        setListAdapter(adapter);
    }

    @Override
    public void onFetchFailure(String msg) {
        // dismiss the progress dialog
        if(dialog != null)  dialog.dismiss();
        // show failure message
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    void dataOpen() {
        AndroidNetworking.get("http://192.168.4.1/?value=0")
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // do anything with response
                    }

                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }


    void dataClose() {
        AndroidNetworking.get("http://192.168.4.1/?value=180")
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // do anything with response
                    }

                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }
}