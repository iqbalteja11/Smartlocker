package com.example.loginbooka;

public class Application {
    private String text;
    private int status_active;

    public String getTextLoker() {
        return text;
    }
    public void setTextLoker(String text) {
        this.text = text;
    }

    public int getStatus_active() {
        return status_active;
    }
    public void setStatus_active(int status_active) {
        this.status_active = status_active;
    }
}
