package com.example.loginbooka;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class AdminPresensiActivity  extends ListActivity implements FetchDataListenerPresensi {

    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_presensi);
        initView();
    }
    @Override
    public void onBackPressed() {
        Intent setIntent = new Intent(AdminPresensiActivity.this, AdminRentLockerActivity.class);
        finish();
        startActivity(setIntent);
    }

    private void initView() {
        // show progress dialog
//        dialog = ProgressDialog.show(this, "", "Loading...");

//        String url = "http://192.168.100.2:8000/APIPresensi";
        String url = "http://192.168.4.2:8000/APIPresensi";
        FetchDataTaskPresensi task = new FetchDataTaskPresensi(this);
        task.execute(url);
    }

    @Override
    public void onFetchComplete(List<ApplicationPresensi> data) {
        // dismiss the progress dialog
        if(dialog != null)  dialog.dismiss();
        // create new adapter
        ApplicationAdapterPresensi adapter = new ApplicationAdapterPresensi(this, data);
        // set the adapter to list
        setListAdapter(adapter);
    }

    @Override
    public void onFetchFailure(String msg) {
        // dismiss the progress dialog
        if(dialog != null)  dialog.dismiss();
        // show failure message
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

}