package com.example.loginbooka;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.loginbooka.app.AppController;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SignInActivity extends AppCompatActivity {
    EditText inputemail, inputPassword;
    String email, password;
    Button btnlogin;
    ProgressDialog pDialog;
    private String url = Server.URL + "/APILogin";

    int role, success;
    ConnectivityManager conMgr;


    private static final String TAG = SignInActivity.class.getSimpleName();

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_ROLE = "role";
    private static final String TAG_MESSAGE = "message";

    public final static String TAG_USERNAME = "name";

    String tag_json_obj = "json_obj_req";

    SharedPreferences sharedpreferences;
    Boolean session = false;
    String id, name;
    public static final String my_shared_preferences = "my_shared_preferences";
    public static final String session_status = "session_status";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        inputemail = findViewById(R.id.edit_txt_1_sign_in);
        inputPassword = findViewById(R.id.edit_txt_2_sign_in);
        btnlogin = findViewById(R.id.btn_sign_in);

        TextView txt_header_5_sign_in = (TextView) findViewById(R.id.txt_header_5_sign_in);

        txt_header_5_sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignInActivity.this, RegisterActivity.class));
            }
        });

        btnlogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                String email = inputemail.getText().toString();
                String password = inputPassword.getText().toString();

                // mengecek kolom yang kosong
                if (email.trim().length() > 0 && password.trim().length() > 0) {
                    checkLogin(email, password);
                } else {
                    // Prompt user to enter credentials
                    Toast.makeText(getApplicationContext() ,"Kolom tidak boleh kosong", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void checkLogin(final String email, final String password) {
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Logging in ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.e(TAG, "Login Response: " + response.toString());
                hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    success = jObj.getInt(TAG_SUCCESS);
                    role = jObj.getInt(TAG_ROLE);

                    // Check for error node in json
                    if (success == 1) {
                        if (role == 1) {
                            String name = jObj.getString(TAG_USERNAME);

                            Log.e("Successfully Login!", jObj.toString());

//                        Toast.makeText(getApplicationContext(), jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();
                            Toast.makeText(getApplicationContext(), name, Toast.LENGTH_LONG).show();

                            // menyimpan login ke session
                            SharedPreferences shared = PreferenceManager.getDefaultSharedPreferences(SignInActivity.this);
                            SharedPreferences.Editor editor = shared.edit();
                            editor.putBoolean(session_status, true);
                            editor.putString(TAG_USERNAME, name);
                            editor.apply();
//
//                        // Memanggil main activity
                            Intent intent = new Intent(SignInActivity.this, AdminRentLockerActivity.class);
                            intent.putExtra(TAG_USERNAME, name);
                            finish();
                            startActivity(intent);
                        }else{
                            String name = jObj.getString(TAG_USERNAME);

                            Log.e("Successfully Login!", jObj.toString());

//                        Toast.makeText(getApplicationContext(), jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();
                            Toast.makeText(getApplicationContext(), name, Toast.LENGTH_LONG).show();

                            // menyimpan login ke session
                            SharedPreferences shared = PreferenceManager.getDefaultSharedPreferences(SignInActivity.this);
                            SharedPreferences.Editor editor = shared.edit();
                            editor.putBoolean(session_status, true);
                            editor.putString(TAG_USERNAME, name);
                            editor.apply();
//
//                        // Memanggil main activity
                            Intent intent = new Intent(SignInActivity.this, LockersActivity.class);
                            intent.putExtra(TAG_USERNAME, name);
                            finish();
                            startActivity(intent);
                        }

                    } else {
                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();

                hideDialog();

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("email", email);
                params.put("password", password);

                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_json_obj);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

}