package com.example.loginbooka;

public class ApplicationPresensi {
    private String text;
    private String date_login;

    public String getTextPresensi() {
        return text;
    }
    public void setTextPresensi(String text) {
        this.text = text;
    }

    public String getDateLogin() {
        return date_login;
    }
    public void setDateLogin(String date_login) {
        this.date_login = date_login;
    }
}
