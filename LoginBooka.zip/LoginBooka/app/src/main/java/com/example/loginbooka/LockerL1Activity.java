package com.example.loginbooka;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Objects;

public class LockerL1Activity extends AppCompatActivity implements View.OnClickListener{
    private IntentIntegrator intentIntegrator;
    private Button btn_rent_a_locker_l1;
    private static final String TAG_LOKER = "loker";
    private String KEY_NAME = "NAMA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locker_l1);
        Bundle extras = getIntent().getExtras();
        String nama = extras.getString(KEY_NAME);
        btn_rent_a_locker_l1 = (Button)findViewById(R.id.btn_rent_a_locker_l1);
        btn_rent_a_locker_l1.setOnClickListener(this);
//        btn_rent_a_locker_l1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(LockerL1Activity.this, UserCheckLockerL1Activity.class);
//                intent.putExtra(KEY_NAME,nama);
//                finish();
//                startActivity(intent);
//            }
//        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        Bundle extras = getIntent().getExtras();
        String nama = extras.getString(KEY_NAME);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "Hasil tidak ditemukan",
                        Toast.LENGTH_SHORT).show();
            } else {
                try {
                    JSONObject object = new JSONObject(result.getContents());
                    String loker = object.getString(TAG_LOKER);
//                    Toast.makeText(this, loker, Toast.LENGTH_SHORT).show();
                    if(Objects.equals(loker, "l1pnj")){
                        Intent i=new Intent(this, UserCheckLockerL1Activity.class);
                        i.putExtra(KEY_NAME,nama);
                        finish();
                        startActivity(i);
//                        Toast.makeText(this, nama, Toast.LENGTH_SHORT).show();
                    }else{
                        Intent i=new Intent(this,FailureScanActivity.class);
                        finish();
                        startActivity(i);
//                        Toast.makeText(this, "loker tidak sesuai", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    // jika format encoded tidak sesuai maka hasil
                    // ditampilkan ke toast
                    Toast.makeText(this, result.getContents(), Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onClick(View v) {         // inisialisasi IntentIntegrator(scanQR)
        intentIntegrator = new IntentIntegrator(this);
        intentIntegrator.initiateScan();
    }
}