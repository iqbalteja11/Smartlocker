package com.example.loginbooka;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LockersActivity extends AppCompatActivity {
    TextView txt_username;
    String username;
    SharedPreferences sharedpreferences;
    public static final String TAG_USERNAME = "name";
    private String KEY_NAME = "NAMA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lockers);

        txt_username = (TextView) findViewById(R.id.name);

        sharedpreferences = getSharedPreferences(SignInActivity.my_shared_preferences, Context.MODE_PRIVATE);

        username = getIntent().getStringExtra(TAG_USERNAME);

        txt_username.setText(username);

        Button btn_locker_l1 = (Button)findViewById(R.id.btn_locker_1);

        btn_locker_l1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LockersActivity.this, LockerL1Activity.class);
                intent.putExtra(KEY_NAME, username);
                Log.d("data", username);
                startActivity(intent);
            }
        });
    }
}