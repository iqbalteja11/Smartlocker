package com.example.loginbooka;


import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.SizeF;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.loginbooka.app.AppController;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterMahasiswaActivity extends AppCompatActivity {

    private EditText editTextName, editTextEmail, editTextJurusan,
            editTextPassword, editTextConfirmPassword, editTextProdi, editTextNIM;

    private Button buttonRegister;

    Intent intent;

    int success;
    ConnectivityManager conMgr;

    private String url = Server.URL + "/APIRegister1";

    private static final String TAG = RegisterTamuActivity.class.getSimpleName();

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    String tag_json_obj = "json_obj_req";
    ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_mahasiswa);

        editTextName = findViewById(R.id.edit_txt_nama_mahasiswa);
        editTextEmail = findViewById(R.id.edit_txt_email_mahasiswa);
        editTextNIM = findViewById(R.id.edit_txt_nim);
        editTextJurusan = findViewById(R.id.spinner_jurusan_mahasiswa);
        editTextProdi = findViewById(R.id.spinner_prodi_mahasiswa);
        editTextPassword = findViewById(R.id.edit_txt_password_mahasiswa);
        editTextConfirmPassword = findViewById(R.id.edit_txt_confirm_password_mahasiswa);

        buttonRegister = findViewById(R.id.btn_register);

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                String textName = editTextName.getText().toString();
                String textNIM = editTextNIM.getText().toString();
                String textJurusan = editTextJurusan.getText().toString();
                String textProdi = editTextProdi.getText().toString();
                String textEmail = editTextEmail.getText().toString();
                String textPassword = editTextPassword.getText().toString();
                String textConfirmPassword = editTextConfirmPassword.getText().toString();
                checkRegister(
                        textName, textPassword, textNIM, textJurusan, textProdi,
                        textEmail, textConfirmPassword);

            }
        });


    }

    private void checkRegister(
                                final String textEmail,
                                final String textName,
                                final String textNIM,
                                final String textJurusan,
                                final String textProdi,
                                final String textPassword,
                                final String textConfirmPassword){
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Register ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.e(TAG, "Register Response: " + response.toString());
                hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    success = jObj.getInt(TAG_SUCCESS);

                    // Check for error node in json
                    if (success == 1) {

                        intent = new Intent(RegisterMahasiswaActivity.this, SignInActivity.class);
                        finish();
                        startActivity(intent);

                    } else {
                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();

                hideDialog();

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("name", textEmail);
                params.put("nim", textNIM);
                params.put("jurusan", textJurusan);
                params.put("prodi", textProdi);
                params.put("email", textPassword);
                params.put("password", textName);
//                params.put("confirm_password", textConfirmPassword);

                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_json_obj);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }


}